import React from "react";

export default function Footer(){
  return (
    <footer className="bg-gray-900 text-gray-200 py-6 text-center mt-8">
      <p>© {new Date().getFullYear()} RKbyte. Smart Automation. Real Impact.</p>
    </footer>
  );
}
