import React, {useState} from "react";
import { Link } from "react-router-dom";
import { Menu, X } from "lucide-react";

export default function Navbar(){
  const [open,setOpen] = useState(false);
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-between p-4">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded bg-rkbg flex items-center justify-center text-rkaccent font-bold">RK</div>
          <div className="font-semibold">RKbyte</div>
        </Link>
        <nav className="hidden md:flex gap-6 items-center text-sm">
          <Link to="/category/biotech" className="hover:text-rkaccent">Biotech</Link>
          <Link to="/category/agriculture" className="hover:text-rkaccent">Agriculture</Link>
          <Link to="/category/industrial" className="hover:text-rkaccent">Industrial</Link>
          <Link to="/category/home-automation" className="hover:text-rkaccent">Home</Link>
          <a href="#contact" className="bg-rkaccent text-white px-4 py-2 rounded">Contact</a>
        </nav>
        <button className="md:hidden" onClick={()=>setOpen(!open)} aria-label="menu">
          {open ? <X/> : <Menu/>}
        </button>
      </div>
      {open && (
        <div className="md:hidden bg-white border-t">
          <div className="flex flex-col p-4 gap-3">
            <Link to="/category/biotech" onClick={()=>setOpen(false)}>Biotech</Link>
            <Link to="/category/agriculture" onClick={()=>setOpen(false)}>Agriculture</Link>
            <Link to="/category/industrial" onClick={()=>setOpen(false)}>Industrial</Link>
            <Link to="/category/home-automation" onClick={()=>setOpen(false)}>Home</Link>
            <a href="#contact" className="mt-2 bg-rkaccent text-white px-4 py-2 rounded">Contact</a>
          </div>
        </div>
      )}
    </header>
  );
}
